<div id="buildship-chat-widget-container" class="buildship-chat-widget-container">
  <button data-buildship-chat-widget-button><?php echo _e($button_name); ?></button>
</div>